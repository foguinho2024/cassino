from flask import Flask, render_template, request, redirect, session
import sqlite3
import random

app = Flask(__name__)
app.secret_key = 'supersecretkey'

def init_db():
    with sqlite3.connect("database.db") as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, balance INTEGER DEFAULT 100)")

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect('/slot/classica')
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        try:
            with sqlite3.connect("database.db") as conn:
                conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            return redirect('/login')
        except sqlite3.IntegrityError:
            return "Usuário já existe!"
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        with sqlite3.connect("database.db") as conn:
            user = conn.execute("SELECT id FROM users WHERE username = ? AND password = ?", (username, password)).fetchone()
            if user:
                session['user_id'] = user[0]
                return redirect('/slot/classica')
            else:
                return "Login inválido!"
    return render_template('login.html')

@app.route('/slot/<machine>', methods=['GET', 'POST'])
def slot(machine):
    if 'user_id' not in session:
        return redirect('/login')

    machines = {
        'classica': {'cost': 10, 'reward': 50, 'symbols': ['🍒', '🍋', '🍇', '🔔']},
        'media': {'cost': 25, 'reward': 120, 'symbols': ['💎', '🍀', '🎲', '💰']},
        'vip': {'cost': 50, 'reward': 300, 'symbols': ['👑', '🤑', '🔥', '🎉']}
    }

    if machine not in machines:
        return "Máquina inválida!"

    config = machines[machine]
    result = []
    message = ''
    balance = 0

    with sqlite3.connect("database.db") as conn:
        cur = conn.cursor()
        balance = cur.execute("SELECT balance FROM users WHERE id = ?", (session['user_id'],)).fetchone()[0]

    if request.method == 'POST':
        if balance < config['cost']:
            message = "Saldo insuficiente!"
        else:
            result = [random.choice(config['symbols']) for _ in range(3)]
            win = result[0] == result[1] == result[2]
            with sqlite3.connect("database.db") as conn:
                if win:
                    balance += config['reward']
                    message = f"Parabéns! Você ganhou R$ {config['reward']}!"
                else:
                    balance -= config['cost']
                    message = f"Você perdeu R$ {config['cost']}. Tente novamente!"
                conn.execute("UPDATE users SET balance = ? WHERE id = ?", (balance, session['user_id']))

    return render_template('slot.html', result=result, message=message, balance=balance, machine=machine, config=config)

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    init_db()
    app.run(debug=True)